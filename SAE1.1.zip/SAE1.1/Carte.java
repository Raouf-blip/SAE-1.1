public class Carte{

    private int valeur; //valeur de la carte


    /**
     * retourne la valeur de la carte
     * @return
     */
    public int getCarte(){
        return this.valeur;
    }

    /**
     * un constructeur avec un param`etre de type int qui construit une carte dont
        l'attribut valeur correspond au param`etre passé
     * @param v
     */
    public Carte(int v){
        this.valeur = v;
    }


    /**
     * une méthode toString() qui retourne une chaine contenant la valeur de la carte
        precedee de la lettre 'c' comme c27 ;
     *  @return
     */
    public String toString(){
        return "c" + this.valeur;
    }


}